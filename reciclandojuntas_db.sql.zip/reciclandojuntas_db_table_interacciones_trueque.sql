
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `interacciones_trueque`
--

CREATE TABLE `interacciones_trueque` (
  `id` int(11) NOT NULL,
  `trueque_id` int(11) NOT NULL,
  `interesado_id` int(11) NOT NULL,
  `mensaje` text DEFAULT NULL,
  `fecha_interaccion` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
