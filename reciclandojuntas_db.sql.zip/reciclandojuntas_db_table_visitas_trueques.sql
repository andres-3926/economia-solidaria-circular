
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `visitas_trueques`
--

CREATE TABLE `visitas_trueques` (
  `id` int(11) NOT NULL,
  `trueque_id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `fecha_vista` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
