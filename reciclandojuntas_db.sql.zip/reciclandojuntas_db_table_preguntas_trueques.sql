
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `preguntas_trueques`
--

CREATE TABLE `preguntas_trueques` (
  `id` int(11) NOT NULL,
  `trueque_id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `pregunta` text NOT NULL,
  `respuesta` text DEFAULT NULL,
  `fecha_pregunta` datetime DEFAULT current_timestamp(),
  `fecha_respuesta` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
