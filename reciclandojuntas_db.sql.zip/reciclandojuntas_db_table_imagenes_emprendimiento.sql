
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `imagenes_emprendimiento`
--

CREATE TABLE `imagenes_emprendimiento` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `ruta_imagen` varchar(255) DEFAULT NULL,
  `fecha_subida` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
