
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `valoraciones_trueque`
--

CREATE TABLE `valoraciones_trueque` (
  `id` int(11) NOT NULL,
  `acuerdo_id` int(11) NOT NULL,
  `evaluador_id` int(11) NOT NULL,
  `evaluado_id` int(11) NOT NULL,
  `puntuacion` int(11) DEFAULT NULL CHECK (`puntuacion` between 1 and 5),
  `comentario` text DEFAULT NULL,
  `fecha_valoracion` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
