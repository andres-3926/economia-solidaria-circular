
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `participacion_comunidad`
--

CREATE TABLE `participacion_comunidad` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `comunidad_id` int(11) NOT NULL,
  `rol` enum('participante','facilitador','coordinador') DEFAULT NULL,
  `fecha_union` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
