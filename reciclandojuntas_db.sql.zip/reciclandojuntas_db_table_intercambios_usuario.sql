
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `intercambios_usuario`
--

CREATE TABLE `intercambios_usuario` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `tipo` enum('trueque','colaboración','donación') DEFAULT NULL,
  `fecha` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
