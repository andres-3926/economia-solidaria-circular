
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `numero_documento` varchar(20) NOT NULL,
  `tipo_documento` enum('CC','CE','PPT') NOT NULL,
  `nombre_completo` varchar(100) NOT NULL,
  `celular` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_croatian_ci NOT NULL,
  `correo` varchar(100) DEFAULT NULL,
  `contrasena` varchar(255) NOT NULL,
  `comuna` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_croatian_ci NOT NULL,
  `barrio` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_croatian_ci NOT NULL,
  `direccion` varchar(255) DEFAULT NULL,
  `emprendimiento` varchar(100) NOT NULL,
  `habilitado` tinyint(1) DEFAULT 0,
  `foto` varchar(255) DEFAULT NULL,
  `rol` varchar(50) DEFAULT 'usuario',
  `fecha_registro` datetime DEFAULT current_timestamp(),
  `instagram` varchar(255) DEFAULT NULL,
  `facebook` varchar(255) DEFAULT NULL,
  `resena` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
