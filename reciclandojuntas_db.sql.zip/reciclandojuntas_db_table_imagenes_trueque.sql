
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `imagenes_trueque`
--

CREATE TABLE `imagenes_trueque` (
  `id` int(11) NOT NULL,
  `trueque_id` int(11) NOT NULL,
  `ruta_imagen` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
