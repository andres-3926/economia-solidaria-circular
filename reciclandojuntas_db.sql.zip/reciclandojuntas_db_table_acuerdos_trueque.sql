
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `acuerdos_trueque`
--

CREATE TABLE `acuerdos_trueque` (
  `id` int(11) NOT NULL,
  `trueque_id` int(11) NOT NULL,
  `usuario_a_id` int(11) NOT NULL,
  `usuario_b_id` int(11) NOT NULL,
  `fecha_acuerdo` datetime DEFAULT current_timestamp(),
  `detalles` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
