
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `miembros_comunidad`
--

CREATE TABLE `miembros_comunidad` (
  `usuario_id` int(11) NOT NULL,
  `comunidad_id` int(11) NOT NULL,
  `rol_en_comunidad` enum('miembro','moderador') DEFAULT 'miembro'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
