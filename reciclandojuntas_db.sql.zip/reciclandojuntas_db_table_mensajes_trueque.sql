
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mensajes_trueque`
--

CREATE TABLE `mensajes_trueque` (
  `id` int(11) NOT NULL,
  `trueque_id` int(11) NOT NULL,
  `de_usuario_id` int(11) NOT NULL,
  `para_usuario_id` int(11) NOT NULL,
  `mensaje` text NOT NULL,
  `fecha_envio` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
