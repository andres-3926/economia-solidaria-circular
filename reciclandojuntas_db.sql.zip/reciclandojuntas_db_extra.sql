
--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `acuerdos_trueque`
--
ALTER TABLE `acuerdos_trueque`
  ADD PRIMARY KEY (`id`),
  ADD KEY `trueque_id` (`trueque_id`),
  ADD KEY `usuario_a_id` (`usuario_a_id`),
  ADD KEY `usuario_b_id` (`usuario_b_id`);

--
-- Indices de la tabla `comunidades`
--
ALTER TABLE `comunidades`
  ADD PRIMARY KEY (`id`),
  ADD KEY `creador_id` (`creador_id`);

--
-- Indices de la tabla `imagenes_emprendimiento`
--
ALTER TABLE `imagenes_emprendimiento`
  ADD PRIMARY KEY (`id`),
  ADD KEY `usuario_id` (`usuario_id`);

--
-- Indices de la tabla `imagenes_trueque`
--
ALTER TABLE `imagenes_trueque`
  ADD PRIMARY KEY (`id`),
  ADD KEY `trueque_id` (`trueque_id`);

--
-- Indices de la tabla `interacciones_trueque`
--
ALTER TABLE `interacciones_trueque`
  ADD PRIMARY KEY (`id`),
  ADD KEY `trueque_id` (`trueque_id`),
  ADD KEY `interesado_id` (`interesado_id`);

--
-- Indices de la tabla `intercambios_usuario`
--
ALTER TABLE `intercambios_usuario`
  ADD PRIMARY KEY (`id`),
  ADD KEY `usuario_id` (`usuario_id`);

--
-- Indices de la tabla `mensajes_trueque`
--
ALTER TABLE `mensajes_trueque`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `miembros_comunidad`
--
ALTER TABLE `miembros_comunidad`
  ADD PRIMARY KEY (`usuario_id`,`comunidad_id`),
  ADD KEY `comunidad_id` (`comunidad_id`);

--
-- Indices de la tabla `notificaciones`
--
ALTER TABLE `notificaciones`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `participacion_comunidad`
--
ALTER TABLE `participacion_comunidad`
  ADD PRIMARY KEY (`id`),
  ADD KEY `usuario_id` (`usuario_id`),
  ADD KEY `comunidad_id` (`comunidad_id`);

--
-- Indices de la tabla `preguntas_trueques`
--
ALTER TABLE `preguntas_trueques`
  ADD PRIMARY KEY (`id`),
  ADD KEY `trueque_id` (`trueque_id`),
  ADD KEY `usuario_id` (`usuario_id`);

--
-- Indices de la tabla `reconocimientos_usuario`
--
ALTER TABLE `reconocimientos_usuario`
  ADD PRIMARY KEY (`id`),
  ADD KEY `usuario_id` (`usuario_id`),
  ADD KEY `otorgado_por` (`otorgado_por`);

--
-- Indices de la tabla `saberes_usuario`
--
ALTER TABLE `saberes_usuario`
  ADD PRIMARY KEY (`id`),
  ADD KEY `usuario_id` (`usuario_id`);

--
-- Indices de la tabla `trueques`
--
ALTER TABLE `trueques`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `documento` (`numero_documento`),
  ADD UNIQUE KEY `correo` (`correo`);

--
-- Indices de la tabla `valoraciones_trueque`
--
ALTER TABLE `valoraciones_trueque`
  ADD PRIMARY KEY (`id`),
  ADD KEY `acuerdo_id` (`acuerdo_id`),
  ADD KEY `evaluador_id` (`evaluador_id`),
  ADD KEY `evaluado_id` (`evaluado_id`);

--
-- Indices de la tabla `visitas_trueques`
--
ALTER TABLE `visitas_trueques`
  ADD PRIMARY KEY (`id`),
  ADD KEY `trueque_id` (`trueque_id`),
  ADD KEY `usuario_id` (`usuario_id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `acuerdos_trueque`
--
ALTER TABLE `acuerdos_trueque`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `comunidades`
--
ALTER TABLE `comunidades`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `imagenes_emprendimiento`
--
ALTER TABLE `imagenes_emprendimiento`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `imagenes_trueque`
--
ALTER TABLE `imagenes_trueque`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `interacciones_trueque`
--
ALTER TABLE `interacciones_trueque`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `intercambios_usuario`
--
ALTER TABLE `intercambios_usuario`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `mensajes_trueque`
--
ALTER TABLE `mensajes_trueque`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `notificaciones`
--
ALTER TABLE `notificaciones`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `participacion_comunidad`
--
ALTER TABLE `participacion_comunidad`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `preguntas_trueques`
--
ALTER TABLE `preguntas_trueques`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `reconocimientos_usuario`
--
ALTER TABLE `reconocimientos_usuario`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `saberes_usuario`
--
ALTER TABLE `saberes_usuario`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `trueques`
--
ALTER TABLE `trueques`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `valoraciones_trueque`
--
ALTER TABLE `valoraciones_trueque`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `visitas_trueques`
--
ALTER TABLE `visitas_trueques`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `acuerdos_trueque`
--
ALTER TABLE `acuerdos_trueque`
  ADD CONSTRAINT `acuerdos_trueque_ibfk_1` FOREIGN KEY (`trueque_id`) REFERENCES `trueques` (`id`),
  ADD CONSTRAINT `acuerdos_trueque_ibfk_2` FOREIGN KEY (`usuario_a_id`) REFERENCES `usuarios` (`id`),
  ADD CONSTRAINT `acuerdos_trueque_ibfk_3` FOREIGN KEY (`usuario_b_id`) REFERENCES `usuarios` (`id`);

--
-- Filtros para la tabla `comunidades`
--
ALTER TABLE `comunidades`
  ADD CONSTRAINT `comunidades_ibfk_1` FOREIGN KEY (`creador_id`) REFERENCES `usuarios` (`id`);

--
-- Filtros para la tabla `imagenes_emprendimiento`
--
ALTER TABLE `imagenes_emprendimiento`
  ADD CONSTRAINT `imagenes_emprendimiento_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`);

--
-- Filtros para la tabla `imagenes_trueque`
--
ALTER TABLE `imagenes_trueque`
  ADD CONSTRAINT `imagenes_trueque_ibfk_1` FOREIGN KEY (`trueque_id`) REFERENCES `trueques` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `interacciones_trueque`
--
ALTER TABLE `interacciones_trueque`
  ADD CONSTRAINT `interacciones_trueque_ibfk_1` FOREIGN KEY (`trueque_id`) REFERENCES `trueques` (`id`),
  ADD CONSTRAINT `interacciones_trueque_ibfk_2` FOREIGN KEY (`interesado_id`) REFERENCES `usuarios` (`id`);

--
-- Filtros para la tabla `intercambios_usuario`
--
ALTER TABLE `intercambios_usuario`
  ADD CONSTRAINT `intercambios_usuario_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`);

--
-- Filtros para la tabla `miembros_comunidad`
--
ALTER TABLE `miembros_comunidad`
  ADD CONSTRAINT `miembros_comunidad_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`),
  ADD CONSTRAINT `miembros_comunidad_ibfk_2` FOREIGN KEY (`comunidad_id`) REFERENCES `comunidades` (`id`);

--
-- Filtros para la tabla `participacion_comunidad`
--
ALTER TABLE `participacion_comunidad`
  ADD CONSTRAINT `participacion_comunidad_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`),
  ADD CONSTRAINT `participacion_comunidad_ibfk_2` FOREIGN KEY (`comunidad_id`) REFERENCES `comunidades` (`id`);

--
-- Filtros para la tabla `preguntas_trueques`
--
ALTER TABLE `preguntas_trueques`
  ADD CONSTRAINT `preguntas_trueques_ibfk_1` FOREIGN KEY (`trueque_id`) REFERENCES `trueques` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `preguntas_trueques_ibfk_2` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `reconocimientos_usuario`
--
ALTER TABLE `reconocimientos_usuario`
  ADD CONSTRAINT `reconocimientos_usuario_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`),
  ADD CONSTRAINT `reconocimientos_usuario_ibfk_2` FOREIGN KEY (`otorgado_por`) REFERENCES `usuarios` (`id`);

--
-- Filtros para la tabla `saberes_usuario`
--
ALTER TABLE `saberes_usuario`
  ADD CONSTRAINT `saberes_usuario_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`);

--
-- Filtros para la tabla `valoraciones_trueque`
--
ALTER TABLE `valoraciones_trueque`
  ADD CONSTRAINT `valoraciones_trueque_ibfk_1` FOREIGN KEY (`acuerdo_id`) REFERENCES `acuerdos_trueque` (`id`),
  ADD CONSTRAINT `valoraciones_trueque_ibfk_2` FOREIGN KEY (`evaluador_id`) REFERENCES `usuarios` (`id`),
  ADD CONSTRAINT `valoraciones_trueque_ibfk_3` FOREIGN KEY (`evaluado_id`) REFERENCES `usuarios` (`id`);

--
-- Filtros para la tabla `visitas_trueques`
--
ALTER TABLE `visitas_trueques`
  ADD CONSTRAINT `visitas_trueques_ibfk_1` FOREIGN KEY (`trueque_id`) REFERENCES `trueques` (`id`),
  ADD CONSTRAINT `visitas_trueques_ibfk_2` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`);
