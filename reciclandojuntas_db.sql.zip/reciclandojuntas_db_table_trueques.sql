
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `trueques`
--

CREATE TABLE `trueques` (
  `id` int(11) NOT NULL,
  `numero_documento` varchar(50) NOT NULL,
  `que_ofreces` varchar(255) NOT NULL,
  `que_necesitas` varchar(255) NOT NULL,
  `descripcion` text NOT NULL,
  `barrio` varchar(100) DEFAULT NULL,
  `etiquetas` varchar(255) DEFAULT NULL,
  `estado` varchar(50) DEFAULT 'activo',
  `fecha_publicacion` datetime DEFAULT NULL,
  `categoria` varchar(50) DEFAULT NULL,
  `subcategoria` varchar(100) DEFAULT NULL,
  `fecha_expiracion` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
